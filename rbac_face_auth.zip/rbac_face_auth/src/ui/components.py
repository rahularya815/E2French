import streamlit as st
from typing import List, Optional


def sidebar_menu(
    role: str,
    authenticated: bool,
    username: Optional[str] = None,
    profile_image_path: Optional[str] = None,
) -> str:
    # User card
    with st.sidebar:
        st.markdown(
            """
            <style>
            /* Sidebar aesthetic */
            section[data-testid="stSidebar"] > div {
                background-color: #FFFFFF; /* match overall UI background */
            }
            .sidebar-user-card img {
                border-radius: 50%;
                border: 2px solid #d0d7e2;
            }
            </style>
            """,
            unsafe_allow_html=True,
        )
        st.markdown("## 🛡️ RBAC Face Auth")
        if authenticated:
            if profile_image_path:
                st.markdown('<div class="sidebar-user-card">', unsafe_allow_html=True)
                st.image(profile_image_path, width=96, caption=None)
                st.markdown("</div>", unsafe_allow_html=True)
            else:
                # Minimal placeholder using emoji in markdown
                st.markdown("### 👤")
            st.markdown(f"**{username or 'User'}**")
            st.caption(role or "")

        # Navigation
        options_map = []  # list of (key, label)
        if authenticated:
            options_map.append(("Dashboard", "🏠 Dashboard"))
            if role == "Admin":
                options_map.append(("Register User", "🧑‍💼 Register User"))
            options_map.append(("Logout", "🚪 Logout"))
        else:
            options_map.append(("Login", "🔐 Login"))

        labels = [lbl for _, lbl in options_map]
        keys = [key for key, _ in options_map]

        with st.expander("Navigation", expanded=True):
            selected_label = st.radio("Navigate", labels, index=0)

    # Map back to logical key
    return keys[labels.index(selected_label)]
