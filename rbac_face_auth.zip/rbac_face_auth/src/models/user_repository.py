from typing import Optional, Tuple
from datetime import datetime

from src.database.db import get_connection
from src.auth.security import hash_password, verify_password as _verify_pw


ROLES = ["Admin", "Manager", "User"]


class UserRepository:
    def create_user(self, username: str, password: str, role: str) -> int:
        if role not in ROLES:
            raise ValueError(f"Invalid role: {role}")
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO users (username, password_hash, role, created_at, face_registered) VALUES (?,?,?,?,?)",
                (username, hash_password(password), role, datetime.utcnow().isoformat(), 0),
            )
            conn.commit()
            return cur.lastrowid

    def get_user_by_username(self, username: str) -> Optional[dict]:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE username = ?", (username,))
            row = cur.fetchone()
            return dict(row) if row else None

    def get_user_by_id(self, user_id: int) -> Optional[dict]:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
            row = cur.fetchone()
            return dict(row) if row else None

    def verify_password(self, username: str, password: str) -> Tuple[bool, Optional[dict]]:
        user = self.get_user_by_username(username)
        if not user:
            return False, None
        if _verify_pw(password, user["password_hash"]):
            return True, user
        return False, user

    def set_face_registered(self, user_id: int, face_registered: bool = True) -> None:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "UPDATE users SET face_registered = ? WHERE id = ?",
                (1 if face_registered else 0, user_id),
            )
            conn.commit()

    def set_profile_image(self, user_id: int, image_path: Optional[str]) -> None:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "UPDATE users SET profile_image = ? WHERE id = ?",
                (image_path, user_id),
            )
            conn.commit()

    def get_profile_image(self, user_id: int) -> Optional[str]:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT profile_image FROM users WHERE id = ?", (user_id,))
            row = cur.fetchone()
            if not row:
                return None
            return row["profile_image"]
