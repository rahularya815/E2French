from pathlib import Path


def get_project_root() -> Path:
    # src/utils/paths.py -> parents[2] is project root
    return Path(__file__).resolve().parents[2]


def get_data_dir() -> Path:
    data_dir = get_project_root() / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def get_db_path() -> Path:
    return get_data_dir() / "app.db"


def get_faces_dir() -> Path:
    faces_dir = get_data_dir() / "faces"
    faces_dir.mkdir(parents=True, exist_ok=True)
    return faces_dir


def get_model_path() -> Path:
    # LBPH trained model
    return get_data_dir() / "face_model.yml"


def get_profiles_dir() -> Path:
    profiles_dir = get_data_dir() / "profiles"
    profiles_dir.mkdir(parents=True, exist_ok=True)
    return profiles_dir
