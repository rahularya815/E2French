import sqlite3
from datetime import datetime
from typing import Optional

from src.utils.paths import get_db_path
from src.auth.security import hash_password


def get_connection() -> sqlite3.Connection:
    db_path = str(get_db_path())
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('Admin','Manager','User')),
            created_at TEXT NOT NULL,
            face_registered INTEGER NOT NULL DEFAULT 0,
            profile_image TEXT
        )
        """
    )

    # In case table existed without profile_image, try to add it.
    try:
        cur.execute("ALTER TABLE users ADD COLUMN profile_image TEXT")
    except sqlite3.OperationalError:
        # Column likely exists; ignore
        pass

    # Ensure default admin exists
    cur.execute("SELECT id FROM users WHERE username = ?", ("admin",))
    row = cur.fetchone()
    if row is None:
        cur.execute(
            "INSERT INTO users (username, password_hash, role, created_at, face_registered) VALUES (?,?,?,?,?)",
            ("admin", hash_password("admin"), "Admin", datetime.utcnow().isoformat(), 0),
        )

    conn.commit()
    conn.close()
