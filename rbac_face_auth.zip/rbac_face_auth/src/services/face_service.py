from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, List, Optional, Tuple

import cv2
import numpy as np

from src.utils.paths import get_faces_dir, get_model_path


class FaceService:
    def __init__(self) -> None:
        cascade_path = str(Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml")
        self.face_cascade = cv2.CascadeClassifier(cascade_path)
        self.model_path = get_model_path()
        self.model = None  # type: Optional[cv2.face_LBPHFaceRecognizer]

    def _create_recognizer(self):
        # Requires opencv-contrib-python
        return cv2.face.LBPHFaceRecognizer_create(radius=1, neighbors=8, grid_x=8, grid_y=8)

    def _open_camera(self, camera_index: int) -> cv2.VideoCapture:
        # Try a few backends for Windows reliability
        api_prefs = []
        # Some builds expose these attributes; guard if missing
        for attr in ["CAP_DSHOW", "CAP_MSMF", "CAP_ANY"]:
            if hasattr(cv2, attr):
                api_prefs.append(getattr(cv2, attr))

        cap = None
        for api in api_prefs:
            try:
                c = cv2.VideoCapture(camera_index, api)
            except Exception:
                c = cv2.VideoCapture(camera_index)
            if c is not None and c.isOpened():
                cap = c
                break

        if cap is None or not cap.isOpened():
            cap = cv2.VideoCapture(camera_index)

        # Set a reasonable frame size
        if cap is not None and cap.isOpened():
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        return cap

    def ensure_model_loaded(self) -> bool:
        if self.model is not None:
            return True
        if self.model_path.exists():
            self.model = self._create_recognizer()
            self.model.read(str(self.model_path))
            return True
        return False

    def capture_faces_for_user(
        self,
        user_id: int,
        num_samples: int = 20,
        camera_index: int = 0,
        on_frame: Optional[Callable[[np.ndarray], None]] = None,
        on_progress: Optional[Callable[[int, int], None]] = None,
        timeout_seconds: int = 25,
    ) -> int:
        faces_base = get_faces_dir()
        user_dir = faces_base / f"{user_id}"
        user_dir.mkdir(parents=True, exist_ok=True)

        cap = self._open_camera(camera_index)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open camera (index {camera_index}) for face capture.")

        captured = 0
        start = time.time()
        try:
            while captured < num_samples and (time.time() - start) < timeout_seconds:
                ok, frame = cap.read()
                if not ok:
                    continue
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                gray = cv2.equalizeHist(gray)
                faces = self.face_cascade.detectMultiScale(
                    gray, scaleFactor=1.2, minNeighbors=5, minSize=(80, 80)
                )

                # Draw guide rectangle
                for (x, y, w, h) in faces:
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

                if len(faces) > 0:
                    # Take the largest face
                    (x, y, w, h) = sorted(faces, key=lambda r: r[2] * r[3], reverse=True)[0]
                    roi = gray[y : y + h, x : x + w]
                    roi = cv2.resize(roi, (200, 200))
                    roi = cv2.equalizeHist(roi)
                    img_path = user_dir / f"img_{int(time.time()*1000)}_{captured}.jpg"
                    cv2.imwrite(str(img_path), roi)
                    captured += 1

                if on_frame is not None:
                    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    on_frame(rgb)
                if on_progress is not None:
                    on_progress(captured, num_samples)

                # Small delay to avoid overwhelming CPU
                cv2.waitKey(5)
        finally:
            cap.release()
        return captured

    def train_model_from_dataset(self) -> Tuple[int, int]:
        faces_base = get_faces_dir()
        image_paths: List[Path] = list(faces_base.rglob("*.jpg"))
        if not image_paths:
            raise RuntimeError("No face images found. Please register users with face capture first.")

        labels: List[int] = []
        images: List[np.ndarray] = []
        for img_path in image_paths:
            try:
                label = int(img_path.parent.name)
            except ValueError:
                # Skip unknown directories
                continue
            img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            images.append(img)
            labels.append(label)

        if not images:
            raise RuntimeError("Dataset is empty after parsing. Ensure images are valid.")

        recognizer = self._create_recognizer()
        recognizer.train(images, np.array(labels))

        # Save
        self.model_path.parent.mkdir(parents=True, exist_ok=True)
        recognizer.write(str(self.model_path))

        # Invalidate cache and load
        self.model = None
        self.ensure_model_loaded()

        return len(set(labels)), len(images)

    def live_recognize(
        self,
        on_frame: Optional[Callable[[np.ndarray], None]] = None,
        timeout_seconds: int = 30,
        threshold: float = 65.0,
        camera_index: int = 0,
    ) -> Optional[int]:
        if not self.ensure_model_loaded():
            return None

        cap = self._open_camera(camera_index)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open camera (index {camera_index}) for recognition.")

        recognized_user: Optional[int] = None
        start = time.time()

        try:
            while (time.time() - start) < timeout_seconds and recognized_user is None:
                ok, frame = cap.read()
                if not ok:
                    continue
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                gray = cv2.equalizeHist(gray)
                faces = self.face_cascade.detectMultiScale(
                    gray, scaleFactor=1.2, minNeighbors=5, minSize=(80, 80)
                )

                for (x, y, w, h) in faces:
                    roi = gray[y : y + h, x : x + w]
                    roi = cv2.resize(roi, (200, 200))
                    roi = cv2.equalizeHist(roi)

                    label, confidence = self.model.predict(roi)  # lower is better
                    # Visual aid
                    color = (0, 255, 0) if confidence < threshold else (0, 0, 255)
                    cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
                    cv2.putText(
                        frame,
                        f"ID:{label} conf:{confidence:.1f}",
                        (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.6,
                        color,
                        2,
                    )

                    if confidence < threshold:
                        recognized_user = int(label)
                        break

                if on_frame is not None:
                    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    on_frame(rgb)

                cv2.waitKey(5)
        finally:
            cap.release()

        return recognized_user
