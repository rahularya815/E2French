# RBAC Face Auth (Streamlit + SQLite)

A scalable Streamlit project template with:

- Role-based access control (RBAC) with roles: Admin, Manager, User
- Admin-only registration of new users
- Username/password login
- Face login with automatic detection when the user appears in front of the camera
- SQLite3 database
- Organized project structure suitable for integrating into AI projects

Default admin account:
- Username: `admin`
- Password: `admin`

## Project Structure

```
rbac_face_auth/
├─ app.py
├─ requirements.txt
├─ README.md
├─ data/
│  ├─ app.db
│  ├─ faces/
│  └─ face_model.yml
└─ src/
   ├─ __init__.py
   ├─ utils/
   │  ├─ __init__.py
   │  └─ paths.py
   ├─ database/
   │  ├─ __init__.py
   │  └─ db.py
   ├─ auth/
   │  ├─ __init__.py
   │  └─ security.py
   ├─ models/
   │  ├─ __init__.py
   │  └─ user_repository.py
   ├─ services/
   │  ├─ __init__.py
   │  └─ face_service.py
   └─ ui/
      ├─ __init__.py
      └─ components.py
```

## Prerequisites
- Python 3.9+
- A working webcam

## Install

```bash
pip install -r requirements.txt
```

On some systems, `opencv-contrib-python` may be large. If installation fails, ensure you have build tools or try a compatible Python version.

## Run

```bash
streamlit run app.py
```

Open the provided local URL in your browser.

## Usage

1. Login as admin (username `admin`, password `admin`).
2. Use the sidebar menu to go to "Register User".
3. Create a new user (Manager/User). After creation, capture their face with your webcam; the system will store ~20 samples and train the model.
4. The user can login either via Username/Password or by using Face Login. In face login, click Start to activate the camera. The system automatically logs in when it recognizes the user.

## Notes
- Face recognition uses OpenCV LBPH (from opencv-contrib). Faces are stored under `data/faces/<user_id>/...` and the model is saved as `data/face_model.yml`.
- Passwords are hashed with PBKDF2-SHA256 via `passlib`.
- SQLite database file is at `data/app.db`.
- Only Admin can register users. Admin can also register more admins if desired by selecting role `Admin`.

## Troubleshooting
- If the camera doesn’t open, ensure no other app is using it and that `VideoCapture(0)` works for your device. Try changing the camera index to 1 or 2 in the code if necessary.
- If face login doesn’t recognize you, register again with better lighting and keep your face within the guide box during capture.
