import time
from typing import Optional

import numpy as np
import streamlit as st
from pathlib import Path
from PIL import Image, ImageDraw

from src.database.db import init_db
from src.models.user_repository import UserRepository, ROLES
from src.services.face_service import FaceService
from src.utils.paths import get_profiles_dir


st.set_page_config(
    page_title="RBAC Face Auth",
    page_icon="🛡️",
    layout="wide",
)

# Initialize DB on startup
init_db()
repo = UserRepository()
face_service = FaceService()


# Session state defaults
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
    st.session_state.username = None
    st.session_state.user_id = None
    st.session_state.role = None

if "face_login_running" not in st.session_state:
    st.session_state.face_login_running = False

if "pending_face_user_id" not in st.session_state:
    st.session_state.pending_face_user_id = None

if "camera_index" not in st.session_state:
    st.session_state.camera_index = 0

if "face_threshold" not in st.session_state:
    st.session_state.face_threshold = 65.0


# Helpers

def do_logout():
    st.session_state.authenticated = False
    st.session_state.username = None
    st.session_state.user_id = None
    st.session_state.role = None
    st.session_state.face_login_running = False
    st.session_state.pending_face_user_id = None
    st.success("Logged out.")


# UI Sections

def render_login():
    st.title("Welcome to RBAC Face Auth")
    tab1, tab2 = st.tabs(["Username & Password", "Face Login"])

    with tab1:
        st.subheader("Login with Credentials")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.button("Login"):
            ok, user = repo.verify_password(username, password)
            if ok and user:
                st.session_state.authenticated = True
                st.session_state.username = user["username"]
                st.session_state.user_id = user["id"]
                st.session_state.role = user["role"]
                st.rerun()
            else:
                st.error("Invalid username or password.")

    with tab2:
        st.subheader("Login with Face")
        has_model = face_service.ensure_model_loaded()
        if not has_model:
            st.info("No trained face model found. Please ask Admin to register your face first.")

        col_settings, col_actions = st.columns([2, 1])
        with col_settings:
            st.session_state.camera_index = st.selectbox(
                "Camera index", options=[0, 1, 2], index=min(st.session_state.camera_index, 2)
            )
            st.session_state.face_threshold = st.slider(
                "Recognition sensitivity (lower = stricter)",
                min_value=40.0,
                max_value=90.0,
                value=float(st.session_state.face_threshold),
                step=1.0,
            )
        with col_actions:
            start = st.button("Start Camera", disabled=not has_model)
            stop = st.button("Stop")
            if start:
                st.session_state.face_login_running = True
            if stop:
                st.session_state.face_login_running = False

        frame_placeholder = st.empty()
        status_placeholder = st.empty()

        if st.session_state.face_login_running and has_model:
            status_placeholder.info("Camera active. Please look at the camera. Auto-detecting...")

            def on_frame(rgb: np.ndarray):
                frame_placeholder.image(rgb, channels="RGB")

            try:
                user_id = face_service.live_recognize(
                    on_frame=on_frame,
                    timeout_seconds=30,
                    threshold=float(st.session_state.face_threshold),
                    camera_index=int(st.session_state.camera_index),
                )
            except Exception as e:
                st.session_state.face_login_running = False
                status_placeholder.error(str(e))
                return

            st.session_state.face_login_running = False
            if user_id is not None:
                user = repo.get_user_by_id(int(user_id))
                if user is not None:
                    st.session_state.authenticated = True
                    st.session_state.username = user["username"]
                    st.session_state.user_id = user["id"]
                    st.session_state.role = user["role"]
                    st.success(f"Welcome, {user['username']}! Logging you in...")
                    time.sleep(0.5)
                    st.rerun()
                else:
                    status_placeholder.error("Recognized unknown user ID. Please re-register.")
            else:
                status_placeholder.warning("No face recognized within time limit.")


def render_dashboard():
    st.title("Dashboard")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("User", st.session_state.username or "-", help="Current username")
    with col2:
        st.metric("Role", st.session_state.role or "-", help="Access level")
    with col3:
        st.metric("User ID", st.session_state.user_id or "-", help="Internal ID")

    st.info(
        "This dashboard is a placeholder. Integrate your AI project components here with the current user's context."
    )


def render_register_user():
    st.title("Register New User (Admin)")
    st.caption("Fill details and capture face samples. Only Admin can access this page.")

    with st.form("register_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        role = st.selectbox("Role", ROLES, index=2)
        submitted = st.form_submit_button("Create User")

    if submitted:
        if not username or not password:
            st.error("Username and password are required.")
        else:
            try:
                user_id = repo.create_user(username, password, role)
                st.session_state.pending_face_user_id = user_id
                st.success(f"User '{username}' created with ID {user_id}. Proceed to capture face.")
            except Exception as e:
                st.error(f"Failed to create user: {e}")

    pending_id: Optional[int] = st.session_state.pending_face_user_id
    if pending_id is not None:
        tab_prof, tab_faces = st.tabs(["Profile Picture", "Face Samples"])

        with tab_prof:
            st.subheader("Profile Picture")
            st.write("Capture a profile picture using your webcam or upload an image.")
            colA, colB = st.columns(2)
            with colA:
                cam_photo = st.camera_input("Take a profile photo")
                if cam_photo is not None:
                    try:
                        img = Image.open(cam_photo).convert("RGB")
                        save_path = get_profiles_dir() / f"{pending_id}.jpg"
                        img.save(str(save_path), format="JPEG", quality=90)
                        repo.set_profile_image(pending_id, str(save_path))
                        st.success("Profile photo saved.")
                    except Exception as e:
                        st.error(f"Failed to save profile photo: {e}")
            with colB:
                uploaded = st.file_uploader("Upload profile image", type=["png", "jpg", "jpeg"])
                if uploaded is not None:
                    try:
                        img = Image.open(uploaded).convert("RGB")
                        save_path = get_profiles_dir() / f"{pending_id}.jpg"
                        img.save(str(save_path), format="JPEG", quality=90)
                        repo.set_profile_image(pending_id, str(save_path))
                        st.success("Profile photo saved.")
                    except Exception as e:
                        st.error(f"Failed to save profile photo: {e}")

        with tab_faces:
            st.subheader("Capture Face Samples")
            st.write("The system will automatically capture multiple samples when it detects your face.")
            num_samples = st.slider("Number of samples", min_value=10, max_value=50, value=20, step=2)
            col1, col2 = st.columns([3, 1])
            with col2:
                camera_idx = st.selectbox("Camera index", options=[0, 1, 2], index=0)
                start_cap = st.button("Start Capture")
            frame_placeholder = st.empty()
            progress_placeholder = st.empty()
            status_placeholder = st.empty()

            if start_cap:
                progress = st.progress(0, text="Capturing...")

                def on_frame(rgb):
                    frame_placeholder.image(rgb, channels="RGB")

                def on_progress(done, total):
                    pct = int((done / total) * 100)
                    progress.progress(pct, text=f"Capturing {done}/{total}")

                try:
                    captured = face_service.capture_faces_for_user(
                        user_id=pending_id,
                        num_samples=num_samples,
                        on_frame=on_frame,
                        on_progress=on_progress,
                        timeout_seconds=max(20, int(num_samples * 1.5)),
                        camera_index=int(camera_idx),
                    )
                except Exception as e:
                    status_placeholder.error(str(e))
                    return

                if captured < num_samples:
                    status_placeholder.warning(
                        f"Captured {captured}/{num_samples} samples. Try again for better results."
                    )
                else:
                    status_placeholder.success("Face samples captured successfully. Training model...")
                    try:
                        users_count, images_count = face_service.train_model_from_dataset()
                        repo.set_face_registered(pending_id, True)
                        st.success(
                            f"Model trained. Users with faces: {users_count}, images: {images_count}."
                        )
                        st.session_state.pending_face_user_id = None
                    except Exception as e:
                        st.error(f"Training failed: {e}")


# Sidebar and routing
from src.ui.components import sidebar_menu

if not st.session_state.authenticated:
    choice = sidebar_menu(role="", authenticated=False, username=None, profile_image_path=None)
    render_login()
else:
    profile_path = None
    try:
        if st.session_state.user_id:
            profile_path = repo.get_profile_image(int(st.session_state.user_id))
    except Exception:
        profile_path = None
    # Fallback to default avatar
    if not profile_path:
        default_avatar = get_profiles_dir() / "default.jpg"
        if not default_avatar.exists():
            try:
                img = Image.new("RGB", (128, 128), color=(230, 234, 241))
                draw = ImageDraw.Draw(img)
                # draw circle avatar
                draw.ellipse((16, 8, 112, 104), fill=(200, 205, 215))
                draw.rectangle((40, 88, 88, 128), fill=(200, 205, 215))
                img.save(str(default_avatar), format="JPEG", quality=90)
            except Exception:
                pass
        if default_avatar.exists():
            profile_path = str(default_avatar)
    choice = sidebar_menu(
        role=st.session_state.role or "",
        authenticated=True,
        username=st.session_state.username or "",
        profile_image_path=profile_path,
    )
    if choice == "Dashboard":
        render_dashboard()
    elif choice == "Register User":
        if st.session_state.role != "Admin":
            st.error("Access denied. Only Admin can register users.")
        else:
            render_register_user()
    elif choice == "Logout":
        do_logout()
        st.rerun()
